document.getElementById("kajak").innerHTML =
Math.floor(Math.random() * 20000) ;

document.getElementById("kok").innerHTML =
Math.floor(Math.random() * 2000) ;

document.getElementById("lok").innerHTML =
Math.floor(Math.random() * 100000) ;

document.getElementById("kol").innerHTML =
Math.floor(Math.random() * 10) ;

document.getElementById("asd").innerHTML =
Math.floor(Math.random() * 4) ;

document.getElementById("dsa").innerHTML =
Math.floor(Math.random() * 01100) ;

document.getElementById("qwe").innerHTML =
Math.floor(Math.random() * 500) ;

document.getElementById("ewq").innerHTML =
Math.floor(Math.random() * 100) ;



document.getElementById("tzu").innerHTML =
Math.floor(Math.random() * 10) ;


document.getElementById("uzt").innerHTML =
Math.floor(Math.random() * 1000) ;


document.getElementById("fgh").innerHTML =
Math.floor(Math.random() * 4000) ;


document.getElementById("hgf").innerHTML =
Math.floor(Math.random() * 7000) ;


document.getElementById("vbn").innerHTML =
Math.floor(Math.random() * 4) ;

document.getElementById("nbv").innerHTML =
Math.floor(Math.random() * 8000) ;


document.getElementById("lol").innerHTML =
Math.floor(Math.random() * 12) ;

document.getElementById("yxc").innerHTML =
Math.floor(Math.random() * 50) ;

document.getElementById("cxy").innerHTML =
Math.floor(Math.random() * 10) ;

document.getElementById("rad").innerHTML =
Math.floor(Math.random() * 100) ;

document.getElementById("dar").innerHTML =
Math.floor(Math.random() * 80) ;

document.getElementById("kl").innerHTML =
Math.floor(Math.random() * 10) ;

document.getElementById("lk").innerHTML =
Math.floor(Math.random() * 200) ;